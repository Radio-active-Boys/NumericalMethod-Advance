for i in range(10):
    pass
print(i)
