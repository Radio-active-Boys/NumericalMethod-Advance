# Epsilon

eps = 1
for i in range(10000):
    if (1+eps)>1:
        eps /= 2
    else:
        print("Small : ", eps, "\nNo. of iterations : ", i)
        break