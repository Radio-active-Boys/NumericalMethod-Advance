# e^x

import math
num = int(input())
prev_res, x, it = 0, 1, 1
res = 1.0
while abs(res-prev_res) > 10**(-5):
    prev_res, x = res, x*num/it
    res += x
    it += 1
print(res, math.exp(num), sep = '\11n')