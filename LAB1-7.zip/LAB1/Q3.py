# pipe

from math import sin, pi, cos

def F(t):
    return (t-(sin(2*t)/2))/pi

alphaL = float(input())
a, b = 0, pi
theta = (b+a)/2

while abs(alphaL-F(theta)) > 1e-10:
    if F(theta) < alphaL:
        a = theta
    else:
        b = theta
    theta = (b+a)/2

res = (1-cos(theta))/2
print(res) 