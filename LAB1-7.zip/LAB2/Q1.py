import pandas

def f(x):
    return (x**2) - (2.2*x) + 1.2

l = [[1.1, 1.0, 50], [0.9, 1.0, 50], [1.1, 1.8, 50], 
    [0.9, 1.8, 50], [1.21, 1.0, 50], [1.21, 1.6, 50], 
    [1.21, -1.6, 50]]

for i in l:
    x, omg, it = i[0], i[1], i[2]
    print("set: ", i)
    for j in range(it):
        if abs(f(x))<1e-5:
            print("root found: ", x)
            print('iterations: ', j+1)
            break
        x = x + omg*f(x)
    if j == it-1: print(f"iterations exceeded with {j+1} iterations!")
    print()


