'''
r = int(input("Number of rows/column: "))
matrix = []
for i in range(r):
    a = input(f"Enter row {i+1}: ").strip().split()[:r]
    matrix.append(a)

const = input("\nConstants: ").strip().split()[:r]
'''
import Q3, Q2

r = 3
matrix = [[3,-1, 2],
          [1, 2, 3],
          [2,-2,-1]]
const = [12,
         11,
          2]

soln = [0]*r

matrix, const = Q3.utm(r, matrix, const)
soln = Q2.utm_solve(r, matrix, const, soln)

for i in matrix:
    print(i)
print("solution: ", soln)