'''
r = int(input("Number of rows/column: "))
matrix = []
for i in range(r):
    a = input(f"Enter row {i+1}: ").strip().split()[:r]
    matrix.append(a)

const = input("\nConstants: ").strip().split()[:r]
'''
'''
r = 3
matrix = [[3,-1, 2],
          [1, 2, 3],
          [2,-2,-1]]
const = [12,
         11,
          2]

soln = [0]*r
'''

def utm(r, matrix, const):
    for i in range(r):
        matrix[i].append(const[i])

    for j in range(r):
        com = matrix[j][j]
        for k in range(r+1):
            matrix[j][k] /= com
        for l in range(j+1, r):
            com2 = matrix[l][j]
            for m in range(r+1):
                matrix[l][m] -= com2*matrix[j][m]

    for pp in range(r):
        const[pp] = matrix[pp][r]
        del matrix[pp][r]

    return matrix, const

'''
matrix, const = utm(r, matrix, const)

for i in matrix:
    print(i)
print(const)
'''