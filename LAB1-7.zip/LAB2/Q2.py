'''
r = int(input("Number of rows/column: "))
matrix = []
for i in range(r):
    a = input(f"Enter row {i+1}: ").strip().split()[:r]
    matrix.append(a)

const = input("\nConstants: ").strip().split()[:r]
'''
'''
r = 3
matrix = [[1,-1, 2],
          [0, 1, 7],
          [0, 0,-1]]
const  = [-8,
          -2,
          -20]

soln   = [0]*r
'''

def utm_solve(r, matrix, const, soln):
    for k in range(r-1, -1, -1):
        s = 0
        for l in range(r):
            if l!=k: s += (matrix[k][l]*soln[l])
        soln[k] = (const[k]-s)/matrix[k][k]
    return soln

'''
print(utm_solve(r, matrix, const, soln))
'''