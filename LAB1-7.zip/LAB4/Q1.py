from Gaussian import gauss_solver
from Q2 import f1, f2, f3, f4, f5
import sys

def Newton_Raphson(n, *guesses):

    x = [1 for i in range(5)] # dummy initilisation
    b = [0 for i in range(5)]
    a = [[0 for i in range(5)] for j in range(5)]

    for i in range(len(guesses)):
        x[i] = guesses[i]

    eps = 1e-4
    omg = 1
    itmax = 50

    x1 = x[0]
    x2 = x[1]
    x3 = x[2]
    x4 = x[3]
    x5 = x[4]

    for it in range(itmax):

        y1 = f1(x1,x2,x3,x4,x5)
        y2 = f2(x1,x2,x3,x4,x5)
        y3 = f3(x1,x2,x3,x4,x5)
        y4 = f4(x1,x2,x3,x4,x5)
        y5 = f5(x1,x2,x3,x4,x5)

        a[0][0] = (f1(1.002*x1,x2,x3,x4,x5)-y1)/(0.002*x1)
        a[0][1] = (f1(x1,1.002*x2,x3,x4,x5)-y1)/(0.002*x2)
        a[0][2] = (f1(x1,x2,1.002*x3,x4,x5)-y1)/(0.002*x3)
        a[0][3] = (f1(x1,x2,x3,1.002*x4,x5)-y1)/(0.002*x4)
        a[0][4] = (f1(x1,x2,x3,x4,1.002*x5)-y1)/(0.002*x5)

        a[1][0] = (f2(1.002*x1,x2,x3,x4,x5)-y2)/(0.002*x1)
        a[1][1] = (f2(x1,1.002*x2,x3,x4,x5)-y2)/(0.002*x2)
        a[1][2] = (f2(x1,x2,1.002*x3,x4,x5)-y2)/(0.002*x3)
        a[1][3] = (f2(x1,x2,x3,1.002*x4,x5)-y2)/(0.002*x4)
        a[1][4] = (f2(x1,x2,x3,x4,1.002*x5)-y2)/(0.002*x5)
        
        a[2][0] = (f3(1.002*x1,x2,x3,x4,x5)-y3)/(0.002*x1)
        a[2][1] = (f3(x1,1.002*x2,x3,x4,x5)-y3)/(0.002*x2)
        a[2][2] = (f3(x1,x2,1.002*x3,x4,x5)-y3)/(0.002*x3)
        a[2][3] = (f3(x1,x2,x3,1.002*x4,x5)-y3)/(0.002*x4)
        a[2][4] = (f3(x1,x2,x3,x4,1.002*x5)-y3)/(0.002*x5)
        
        a[3][0] = (f4(1.002*x1,x2,x3,x4,x5)-y4)/(0.002*x1)
        a[3][1] = (f4(x1,1.002*x2,x3,x4,x5)-y4)/(0.002*x2)
        a[3][2] = (f4(x1,x2,1.002*x3,x4,x5)-y4)/(0.002*x3)
        a[3][3] = (f4(x1,x2,x3,1.002*x4,x5)-y4)/(0.002*x4)
        a[3][4] = (f4(x1,x2,x3,x4,1.002*x5)-y4)/(0.002*x5)
        
        a[4][0] = 1
        a[4][1] = 1
        a[4][2] = 1
        a[4][3] = 1
        a[4][4] = 1
        
        b[0] = -y1
        b[1] = -y2
        b[2] = -y3
        b[3] = -y4
        b[4] = -y5
        
        dx = [0 for i in range(5)]
        dx = gauss_solver(n, a, b, dx)

        '''print(a)
        print(dx)
        print()'''

        for i in range(n):
            x[i] = x[i] + omg*dx[i]

        x1 = x[0]
        x2 = x[1]
        x3 = x[2]
        x4 = x[3]
        x5 = x[4]    

        dxmax = max(dx)

        if dxmax < eps:
            print(it+1)
            print(x)
            sys.exit("Solutions Converged!")

    print("Iterations did not converge!")

Newton_Raphson(5, 1, 1, 1, 1, 1)