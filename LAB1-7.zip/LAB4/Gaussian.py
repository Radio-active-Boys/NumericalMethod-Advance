def gauss_solver(r, matrix, const, soln):
    
    '''UTMizer'''

    for i in range(r):
        matrix[i].append(const[i])

    for j in range(r):
        com = matrix[j][j]
        for k in range(r+1):
            matrix[j][k] /= com
        for l in range(j+1, r):
            com2 = matrix[l][j]
            for m in range(r+1):
                matrix[l][m] -= com2*matrix[j][m]

    for pp in range(r):
        const[pp] = matrix[pp][r]
        del matrix[pp][r]

    '''Gaussian Solver'''

    for k in range(r-1, -1, -1):
        s = 0
        for l in range(r):
            if l!=k: s += (matrix[k][l]*soln[l])
        soln[k] = (const[k]-s)/matrix[k][k]
    
    return soln
