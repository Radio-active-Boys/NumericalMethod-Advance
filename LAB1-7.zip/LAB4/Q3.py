from math import pow

N = int(input())
x = [0] * N
y = [0] * N
yy = [0] * 3
xx = [0] * 3

for i in range(N):
    x[i] = float(input())
    y[i] = pow(x[i] + 1, 2)

xxx = float(input())

ii = 0
for i in range(N):
    if x[i] >= xxx:
        ii = i
        break

if ii == 0:
    print("xxx is out of range")
else:
    if ii != N - 1:
        yy[0] = y[ii - 1]
        yy[1] = y[ii]
        yy[2] = y[ii + 1]
        xx[0] = x[ii - 1]
        xx[1] = x[ii]
        xx[2] = x[ii + 1]
    else:
        yy[2] = y[ii]
        yy[1] = y[ii - 1]
        yy[0] = y[ii - 2]
        xx[2] = x[ii]
        xx[1] = x[ii - 1]
        xx[0] = x[ii - 2]

# Lagrange interpolation
yyy = 0
for i in range(3):
    prod = yy[i]
    for j in range(3):
        if i != j:
            prod *= (xxx - xx[j]) / (xx[i] - xx[j])
    yyy += prod

print(yyy, pow(xxx + 1, 2))
