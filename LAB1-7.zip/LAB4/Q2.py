k1, k2, k3, k4, x10 = 1.0, 0.2, 0.05, 0.4, 1
 
def f1(x1, x2, x3, x4, x5):
    return -x1 + x10 + 2*(-k1*x1 - k2*(x1**1.5) + k3*(x3**2))

def f2(x1, x2, x3, x4, x5):
    return -x2 + 2*(2*k1*x1 - k4*(x2**2))

def f3(x1, x2, x3, x4, x5):
    return -x3 + 2*(k2*(x1**1.5) + k4*(x2**2) - k3*(x3**2))

def f4(x1, x2, x3, x4, x5):
    return -x4 + 2*(k4*(x2**2))

def f5(x1, x2, x3, x4, x5):
    return 1