import numpy as np
from math import pow
    
def coeff_i_minus_one(i, x):
    return (x[i]-x[i-1])/6

def coeff_i(i, x):
    return (x[i+1]-x[i-1])/3

def coeff_i_plus_one(i, x):
    return (x[i+1]-x[i])/6

def Ai(x, i, xp):
    return (x[i+1]-xp)/(x[i+1]-x[i])

def Bi(x, i, xp):
    return (xp-x[i])/(x[i+1]-x[i])

def res(i, xp, x, y, f__):
    a1= Ai(x,i,xp)*y[i]
    a2= Bi(x,i,xp)*y[i+1]
    a3= ((x[i+1]-x[i])*(x[i+1]-x[i]))/6
    a4= (pow(Ai(x,i,xp),3)-Ai(x,i,xp))*f__[i]
    a5= (pow(Bi(x,i,xp),3)-Bi(x,i,xp))*f__[i+1]
    return a1+a2+(a3*(a4+a5))

n=11
x =[0.261799,0.523599,0.785398 ,1.047198,1.308997 ,1.570796, 1.832596,2.094395,2.356194,2.617994,2.879793,3.141593]
y =[0.258819, 0.5,0.707107, 0.866025,0.965926, 1,0.965926,0.866025,0.707107  ,0.5  ,0.258819,-3.2E-16]
    
    
A = [[0 for i in range(n-1)] for j in range(n-1)]
for i in range(n-1):
    for j in range(n-1):
        A[i][j]=0
    
B = [0 for i in range(n-1)]
    
    
A[0][0]=coeff_i(1,x)
A[0][1]=coeff_i_plus_one(1,x)

A[9][8]=coeff_i_minus_one(10,x)
A[9][9]=coeff_i(10,x)

for i in range(1, 9):
    A[i][i-1]=coeff_i_minus_one(i+1,x)
    A[i][i]=coeff_i(i+1,x)
    A[i][i+1]=coeff_i_plus_one(i+1,x)


'''for i in range(n-1):
    for j in range(n-1):
        print(A[i][j], end = ' ')'''
print(np.array(A))
print()

for i in range(1, 11):
    B[i-1]=((y[i+1]-y[i])/(x[i+1]-x[i])) - ((y[i]-y[i-1])/(x[i]-x[i-1]))

yyy = [0 for i in range(n-1)]  


A[0][1]=A[0][1]/A[0][0]
B[0]=B[0]/A[0][0]
for i in range(1, n-1):
    if(i<n-2): A[i][i+1]=A[i][i+1]/(A[i][i]-A[i-1][i]*A[i][i-1])
    B[i]=(B[i]-B[i-1]*A[i][i-1])/(A[i][i]-A[i][i-1]*A[i-1][i])

yyy[n-2]=B[n-2];
for i in range(n-3, -1, -1):
    yyy[i]=B[i]-A[i][i+1]*yyy[i+1]

print()

f__=[0 for i in range(n+1)]
for i in range(1, n):
    f__[i]=yyy[i-1]

print("x=1 -> f(x)= ", res(3,1,x,y,f__))
print("x=1.5 -> f(x)= ", res(5,1.5,x,y,f__))
print("x=2 -> f(x)= ", res(7,2,x,y,f__))
print("x=2.5 -> f(x)= ", res(9,2.5,x,y,f__))
print("x=3 -> f(x)= ", res(10   ,3,x,y,f__))

