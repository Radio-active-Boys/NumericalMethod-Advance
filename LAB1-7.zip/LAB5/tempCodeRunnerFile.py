x = np.linalg.solve(a, b)
print(x)
