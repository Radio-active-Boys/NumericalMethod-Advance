# HAX CODE 🤓
import numpy as np

n, F, val = 3, [], {0:1, 1:2, 2:9, 3:28, 4:65, 5:126}
def f(k, x): return x**k

for i in val:
    temp = []
    for j in range(4): temp.append(f(j, i))
    F.append(temp)

F  = np.array(F)
Ft = np.array(np.transpose(F))
a  = np.dot(Ft, F)
b  = np.dot(Ft, np.array(list(val.values())))
ex = np.linalg.solve(a, b)

print(ex)

def finalf(x):
    ans = 0
    for i in range(4):
        ans += ex[i]*f(i, x)
    return ans
for i in range(6):
    print(finalf(i))
print(np.allclose(np.dot(a, ex), b))    # checking if solution is satisfying the matrix equation

for i in range(0, n):
    for j in range(0, n):
        print(a[i][j], end ='')
    print()