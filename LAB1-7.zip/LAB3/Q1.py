def ul(r, a):
    l = [[0]*r for _ in range(r)]
    u = [[0]*r for _ in range(r)]

    # initialising U
    for k in range(r): 
        u[k][k] = 1

    # decomposition begins
    for i in range(r):
        l[i][0] = a[i][0]
    for j in range(1, r):
        u[0][j] = a[0][j] / l[0][0]

    # L operation
    for j in range(1, r-1):
        for i in range(j, r):
            l[i][j] = a[i][j]
            for k in range(0, j):
                l[i][j] -= (l[i][k] * u[k][j])

    # U operation
        for i in range(j+1, r):
            u[j][i] = a[j][i]
            for k in range(0, j):
                u[j][i] -= (l[j][k] * u[k][i])
            u[j][i] /= l[j][j]

    # L[n][n] operation
    l[r-1][r-1] = a[r-1][r-1]
    for k in range(r-1):
        l[r-1][r-1] -= (l[r-1][k] * u[k][r-1])

    return u, l

r = 3

a = [[3, -1,  2],
     [1,  2,  3],
     [2, -2, -1]]

u, l = ul(r, a)

# cool printer
s = [[str(e) for e in row] for row in l]
lens = [max(map(len, col)) for col in zip(*s)]
fmt = '\t'.join('{{:{}}}'.format(x) for x in lens)
table = [fmt.format(*row) for row in s]
print('\n'.join(table))

print()

s = [[str(e) for e in row] for row in u]
lens = [max(map(len, col)) for col in zip(*s)]
fmt = '\t'.join('{{:{}}}'.format(x) for x in lens)
table = [fmt.format(*row) for row in s]
print('\n'.join(table))