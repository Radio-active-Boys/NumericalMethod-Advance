from Q1 import ul

def xfinder(r, a, u, l, b):
    d = [0]*r
    d[0] = b[0] / l[0][0]
    for i in range(1, r):
        s = 0
        for j in range(0, i):
            s += l[i][j] * d[j]
        d[i] = (b[i] - s) / l[i][i]

    x = [0]*r
    x[r-1] = d[r-1] / u[r-1][r-1]
    for i in range(r-1-1, -1, -1):
        s = 0
        for j in range(i+1, r):
            s += u[i][j] * x[j]
        x[i] = (d[i] - s) / u[i][i]

    return x

r = 3

a = [[3, -1,  2],
     [1,  2,  3],
     [2, -2, -1]]

u, l = ul(r, a)

b = [12,
     11,
      2]

print()
x = xfinder(r, a, u, l, b)
print(x)